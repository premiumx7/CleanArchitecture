﻿using System.Threading.Tasks;
using CleanArchitecture.Application.Notifications.Models;

namespace CleanArchitecture.Application.Interfaces
{
    public interface INotificationService
    {
        Task SendAsync(Message message);
    }
}
