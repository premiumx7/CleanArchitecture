﻿namespace CleanArchitecture.Application.Interfaces.Mapping
{
    public interface IMapTo<TEntity>
    {
    }
}
