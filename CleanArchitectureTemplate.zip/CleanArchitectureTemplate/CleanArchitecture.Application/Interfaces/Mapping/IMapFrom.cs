﻿namespace CleanArchitecture.Application.Interfaces.Mapping
{
    public interface IMapFrom<TEntity>
    {
    }
}
