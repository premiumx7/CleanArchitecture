﻿using System.Threading;
using System.Threading.Tasks;
using CleanArchitecture.Domain.Entities;
using CleanArchitecture.Domain.ValueObjects;
using CleanArchitecture.Persistence;
using MediatR;

namespace CleanArchitecture.Application.Users.Commands.CreateUser
{
    public class CreateUserCommandHandler : IRequestHandler<CreateUserCommand, int>
    {
        private readonly CleanArchitectureDbContext _context;

        public CreateUserCommandHandler(CleanArchitectureDbContext context)
        {
            _context = context;
        }

        public async Task<int> Handle(CreateUserCommand request, CancellationToken cancellationToken)
        {

            var entity = new User
            {
                Name = request.Name,
                AdAccount = AdAccount.For($"Microsoft\\{request.Name}"),
                IsActive = true
            };


            _context.Users.Add(entity);
            await _context.SaveChangesAsync(cancellationToken);
    
            return entity.UserId;
        }
    }
}
