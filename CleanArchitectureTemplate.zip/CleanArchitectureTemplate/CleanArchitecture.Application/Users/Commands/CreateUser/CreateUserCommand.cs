﻿using MediatR;

namespace CleanArchitecture.Application.Users.Commands.CreateUser
{
    public class CreateUserCommand : IRequest<int>
    {
        public string Name { get; set; }
    }
}
