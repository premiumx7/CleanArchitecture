﻿using System.Threading;
using System.Threading.Tasks;
using CleanArchitecture.Application.Exceptions;
using CleanArchitecture.Domain.Entities;
using CleanArchitecture.Persistence;
using MediatR;

namespace CleanArchitecture.Application.Users.Commands.DeleteUser
{
    public class DeleteUserCommandHandler : IRequestHandler<DeleteUserCommand, Unit>
    {
        private readonly CleanArchitectureDbContext _context;

        public DeleteUserCommandHandler(CleanArchitectureDbContext context)
        {
            _context = context;
        }


        public async Task<Unit> Handle(DeleteUserCommand request, CancellationToken cancellationToken)
        {
            var entity = await _context.Users.FindAsync(request.UserId);

            if (entity == null)
                throw new NotFoundException(nameof(User), request.UserId);


            _context.Users.Remove(entity);
            await _context.SaveChangesAsync(cancellationToken);

            return Unit.Value;
        }
    }
}
