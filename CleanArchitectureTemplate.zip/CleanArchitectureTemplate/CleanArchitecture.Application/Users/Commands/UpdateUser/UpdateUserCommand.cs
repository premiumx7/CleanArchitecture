﻿using MediatR;

namespace CleanArchitecture.Application.Users.Commands.UpdateUser
{
    public class UpdateUserCommand: IRequest
    {
        public int UserId { get; private set; }
        public string Name { get; set; }
        public bool IsActive { get; set; }

        public void SetUserId(int userId) => UserId = userId;
    }
}
