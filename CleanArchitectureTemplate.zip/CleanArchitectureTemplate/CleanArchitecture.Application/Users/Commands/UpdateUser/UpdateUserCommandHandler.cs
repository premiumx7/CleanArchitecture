﻿using System.Threading;
using System.Threading.Tasks;
using CleanArchitecture.Application.Exceptions;
using CleanArchitecture.Domain.Entities;
using CleanArchitecture.Persistence;
using MediatR;

namespace CleanArchitecture.Application.Users.Commands.UpdateUser
{
    public class UpdateUserCommandHandler : IRequestHandler<UpdateUserCommand, Unit>
    {
        private readonly CleanArchitectureDbContext _context;

        public UpdateUserCommandHandler(CleanArchitectureDbContext context)
        {
            _context = context;
        }

        public async Task<Unit> Handle(UpdateUserCommand request, CancellationToken cancellationToken)
        {
            var entity = await _context.Users.FindAsync(request.UserId);

            if (entity == null)
                throw new NotFoundException(nameof(User), request.UserId);

            UpdateUser(entity, request);

            await _context.SaveChangesAsync(cancellationToken);

            return Unit.Value;
        }

        private static void UpdateUser(User entity, UpdateUserCommand request)
        {
            entity.IsActive = request.IsActive;
            entity.Name = request.Name;
        }
    }
}
