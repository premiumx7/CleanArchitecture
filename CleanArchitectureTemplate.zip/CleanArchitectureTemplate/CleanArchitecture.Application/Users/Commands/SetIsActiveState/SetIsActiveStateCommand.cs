﻿using MediatR;

namespace CleanArchitecture.Application.Users.Commands.SetIsActiveState
{
    public class SetIsActiveStateCommand: IRequest
    {
        public int UserId { get; private set; }
        public bool IsActive { get; set; }

        public void SetUserId(int userId) => UserId = userId;
    }
}
