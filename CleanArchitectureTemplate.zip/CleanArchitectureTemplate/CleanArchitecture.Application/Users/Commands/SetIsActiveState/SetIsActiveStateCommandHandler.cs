﻿using System.Threading;
using System.Threading.Tasks;
using CleanArchitecture.Application.Exceptions;
using CleanArchitecture.Domain.Entities;
using CleanArchitecture.Persistence;
using MediatR;

namespace CleanArchitecture.Application.Users.Commands.SetIsActiveState
{
    public class SetIsActiveStateCommandHandler : IRequestHandler<SetIsActiveStateCommand, Unit>
    {
        private readonly CleanArchitectureDbContext _context;

        public SetIsActiveStateCommandHandler(CleanArchitectureDbContext context)
        {
            _context = context;
        }


        public async Task<Unit> Handle(SetIsActiveStateCommand request, CancellationToken cancellationToken)
        {
            var entity = await _context.Users.FindAsync(request.UserId);

            if (entity == null)
                throw new NotFoundException(nameof(User), request.UserId);

            DeactivateUser(entity, request);

            await _context.SaveChangesAsync(cancellationToken);

            return Unit.Value;
        }

        private static void DeactivateUser(User entity, SetIsActiveStateCommand request)
        {
            entity.IsActive = request.IsActive;
        }
    }
}
