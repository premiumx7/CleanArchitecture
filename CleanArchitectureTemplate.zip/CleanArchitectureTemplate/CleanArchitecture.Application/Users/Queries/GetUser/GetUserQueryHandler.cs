﻿using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using CleanArchitecture.Persistence;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace CleanArchitecture.Application.Users.Queries.GetUser
{
    public class GetUserQueryHandler : IRequestHandler<GetUserQuery, UserDto>
    {
        private readonly CleanArchitectureDbContext _cleanArchitectureDbContext;

        public GetUserQueryHandler(CleanArchitectureDbContext cleanArchitectureDbContext)
        {
            _cleanArchitectureDbContext = cleanArchitectureDbContext;
        }

        public async Task<UserDto> Handle(GetUserQuery request, CancellationToken cancellationToken)
        {
            var user = await _cleanArchitectureDbContext.Users
                .Where(x => x.UserId == request.UserId)
                .Select(UserDto.Projection)
                .SingleOrDefaultAsync(cancellationToken);

            //-------------------------------------------------------------------> SPECIAL CASE
            //if(user == null)
            //        throw new NotFoundException(nameof(User), request.UserId);


            return user;
        }
    }
}