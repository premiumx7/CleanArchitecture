﻿using MediatR;

namespace CleanArchitecture.Application.Users.Queries.GetUser
{
    public class GetUserQuery : IRequest<UserDto>
    {
        public int UserId { get; set; }
    }
}