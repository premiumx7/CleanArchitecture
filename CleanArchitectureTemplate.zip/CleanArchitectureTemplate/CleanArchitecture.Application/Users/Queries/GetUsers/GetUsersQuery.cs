﻿using MediatR;

namespace CleanArchitecture.Application.Users.Queries.GetUsers
{
    public class GetUsersQuery : IRequest<UsersViewModel>
    {
    }
}
