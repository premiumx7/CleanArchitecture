﻿using AutoMapper;
using CleanArchitecture.Application.Interfaces.Mapping;
using CleanArchitecture.Domain.Entities;

namespace CleanArchitecture.Application.Users.Queries.GetUsers
{
    public class UserLookupModel : IHaveCustomMapping
    {
        public string Name { get; set; }
        public bool IsActive { get; set; }
        public string AccountDomain { get; set; }


        public void CreateMappings(Profile configuration)
        {
            configuration.CreateMap<User, UserLookupModel>()
                .ForMember(userDto => userDto.Name, opt => opt.MapFrom(user => user.Name))
                .ForMember(userDto => userDto.IsActive, opt => opt.MapFrom(user => user.IsActive))
                .ForMember(userDto => userDto.AccountDomain, opt => opt.MapFrom(user => user.AdAccount.Domain));
        }
    }
}
