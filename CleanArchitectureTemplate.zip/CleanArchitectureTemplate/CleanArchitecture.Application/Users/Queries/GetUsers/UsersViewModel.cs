﻿using System.Collections.Generic;

namespace CleanArchitecture.Application.Users.Queries.GetUsers
{
    public class UsersViewModel
    {
        public IList<UserLookupModel> Users { get; set; }
    }
}
