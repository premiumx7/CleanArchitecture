﻿using System;
using System.Linq.Expressions;
using CleanArchitecture.Domain.Entities;

public class UserDto
{
    public string Name { get; set; }


    public static Expression<Func<User, UserDto>> Projection => user => 
                                                                        new UserDto
                                                                        {
                                                                             Name = user.Name,
                                                                        };
        
    
}