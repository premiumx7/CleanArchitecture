﻿using System.Net;
using System.Threading.Tasks;
using CleanArchitecture.Application.Users.Commands.CreateUser;
using CleanArchitecture.Application.Users.Commands.DeleteUser;
using CleanArchitecture.Application.Users.Commands.SetIsActiveState;
using CleanArchitecture.Application.Users.Commands.UpdateUser;
using CleanArchitecture.Application.Users.Queries.GetUser;
using CleanArchitecture.Application.Users.Queries.GetUsers;
using Microsoft.AspNetCore.Mvc;

namespace CleanArchitecture.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsersController : BaseController
    {

        [HttpGet]
        public async Task<ActionResult<UsersViewModel>> Get()
        {
            return Ok(await Mediator.Send(new GetUsersQuery()));
        }


        [HttpGet("{userId}")]
        public async Task<ActionResult<UserDto>> Get(int userId)
        {
            return Ok(await Mediator.Send(new GetUserQuery { UserId = userId }));
        }

        [HttpPost]
        public async Task<ActionResult<int>> Create([FromBody] CreateUserCommand command)
        {
            var userId = await Mediator.Send(command);
            return Ok(userId);
        }

        [HttpPatch("{userId}/status/active")]
        public async Task<IActionResult> Update([FromRoute] int userId, [FromBody] SetIsActiveStateCommand command)
        {
            command.SetUserId(userId);
            await Mediator.Send(command);
            return NoContent();
        }

        [HttpPut("{userId}")]
        public async Task<IActionResult> Update([FromRoute] int userId, [FromBody] UpdateUserCommand command)
        {
            command.SetUserId(userId);
            await Mediator.Send(command);
            return NoContent();
        }

        [HttpDelete("{id}")]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        public async Task<IActionResult> Delete(int id)
        {
            await Mediator.Send(new DeleteUserCommand { UserId = id });

            return NoContent();
        }
    }
}
