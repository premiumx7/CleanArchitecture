﻿# Common Layer

This will contain all cross-cutting concerns.