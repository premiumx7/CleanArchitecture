﻿using System;

namespace CleanArchitecture.Common
{
    public interface IDateTime
    {
        DateTime Now { get; }
    }
}
