﻿using CleanArchitecture.Common;
using System;

namespace CleanArchitecture.Infrastructure
{
    public class MachineDateTime : IDateTime
    {
        public DateTime Now => DateTime.Now;
        int CurrentYear => DateTime.Now.Year;
    }
}
