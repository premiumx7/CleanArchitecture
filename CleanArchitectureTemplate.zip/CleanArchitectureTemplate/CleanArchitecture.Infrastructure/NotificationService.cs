﻿using CleanArchitecture.Application.Interfaces;
using System.Threading.Tasks;
using CleanArchitecture.Application.Notifications.Models;

namespace CleanArchitecture.Infrastructure
{
    public class NotificationService : INotificationService
    {
        public Task SendAsync(Message message)
        {
            return Task.CompletedTask;
        }
    }
}
