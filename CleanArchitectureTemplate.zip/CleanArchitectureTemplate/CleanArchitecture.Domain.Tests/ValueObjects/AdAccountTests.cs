﻿using CleanArchitecture.Domain.ValueObjects;
using CleanArchitecture.Domain.Exceptions;
using Xunit;

namespace CleanArchitecture.Domain.Tests.ValueObjects
{
    public class AdAccountTests
    {
        [Fact]
        public void ShouldHaveCorrectDomainAndName()
        {
            var account = AdAccount.For("Microsoft\\James");

            Assert.Equal("Microsoft", account.Domain);
            Assert.Equal("James", account.Name);
        }

        [Fact]
        public void ToStringReturnsCorrectFormat()
        {
            const string value = "Microsoft\\James";

            var account = AdAccount.For(value);

            Assert.Equal(value, account.ToString());
        }

        [Fact]
        public void ImplicitConversionToStringResultsInCorrectString()
        {
            const string value = "Microsoft\\James";

            var account = AdAccount.For(value);

            string result = account;

            Assert.Equal(value, result);
        }

        [Fact]
        public void ExplicitConversionFromStringSetsDomainAndName()
        {
            var account = (AdAccount)"Microsoft\\James";

            Assert.Equal("Microsoft", account.Domain);
            Assert.Equal("James", account.Name);
        }

        [Fact]
        public void ShouldThrowAdAccountInvalidExceptionForInvalidAdAccount()
        {
            Assert.Throws<AdAccountInvalidException>(() => (AdAccount)"MicrosoftJames");
        }
    }
}
