﻿using System;
using CleanArchitecture.Domain.Entities;
using CleanArchitecture.Persistence;
using Microsoft.EntityFrameworkCore;

namespace CleanArchitecture.Application.Tests.Infrastructure
{
    public class CleanArchitectureContextFactory
    {
        public static CleanArchitectureDbContext Create()
        {
            var options = new DbContextOptionsBuilder<CleanArchitectureDbContext>()
                .UseInMemoryDatabase(Guid.NewGuid().ToString())
                .Options;

            var context = new CleanArchitectureDbContext(options);

            context.Database.EnsureCreated();

            context.Users.AddRange(new User {UserId = 1, Name = "Jason"}, 
                new User {UserId = 2, Name = "John"},
                new User {UserId = 3, Name = "Kate"});

            context.SaveChanges();

            return context;
        }

        public static void Destroy(CleanArchitectureDbContext context)
        {
            context.Database.EnsureDeleted();
            context.Dispose();
        }
    }

}
