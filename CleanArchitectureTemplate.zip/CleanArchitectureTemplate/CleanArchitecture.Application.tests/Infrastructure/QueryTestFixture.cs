﻿using System;
using AutoMapper;
using CleanArchitecture.Persistence;
using Xunit;

namespace CleanArchitecture.Application.Tests.Infrastructure
{
    public class QueryTestFixture : IDisposable
    {
        public CleanArchitectureDbContext Context { get; private set; }
        public IMapper Mapper { get; private set; }

        public QueryTestFixture()
        {
            Context = CleanArchitectureContextFactory.Create();
            Mapper = AutoMapperFactory.Create();
        }

        public void Dispose()
        {
            CleanArchitectureContextFactory.Destroy(Context);
        }
    }

    [CollectionDefinition("QueryCollection")]
    public class QueryCollection : ICollectionFixture<QueryTestFixture> { }
}
