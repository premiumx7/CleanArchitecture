﻿using System;
using CleanArchitecture.Persistence;

namespace CleanArchitecture.Application.Tests.Infrastructure
{
    public class CommandTestBase : IDisposable
    {
        protected readonly CleanArchitectureDbContext _context;

        public CommandTestBase()
        {
            _context = CleanArchitectureContextFactory.Create();
        }

        public void Dispose()
        {
            CleanArchitectureContextFactory.Destroy(_context);
        }
    }
}
