﻿using System;
using System.Threading;
using System.Threading.Tasks;
using CleanArchitecture.Application.tests;
using CleanArchitecture.Application.Users.Commands.CreateUser;
using CleanArchitecture.Persistence;
using Microsoft.EntityFrameworkCore;
using Xunit;

namespace CleanArchitecture.Application.Tests.Users.Commands
{
    public class CreateUserCommandHandlerTests : TestBase, IDisposable
    {
        private readonly CleanArchitectureDbContext _context;
        private readonly CreateUserCommandHandler _commandHandler;

        public CreateUserCommandHandlerTests()
        {
            _context = InitAndGetDbContext();
            _commandHandler = new CreateUserCommandHandler(_context);
        }


        [Fact]
        public async Task ShouldNewUserBeAdded()
        {
            // Arrange
            var command = new CreateUserCommand
            {
                Name = "Kate",
            };

            // Act
            await _commandHandler.Handle(command, CancellationToken.None);
            var employee = await _context.Users.FirstAsync(x=> x.Name == command.Name);

            // Assert
            Assert.Equal("Kate",employee.Name);
        }


        private CleanArchitectureDbContext InitAndGetDbContext()
        {
            var context = GetDbContext();
            context.SaveChanges();
            return context;
        }

        public void Dispose()
        {
            _context.Dispose();
        }
    }
}
