﻿using CleanArchitecture.Persistence;
using System.Threading;
using System.Threading.Tasks;
using CleanArchitecture.Application.Tests.Infrastructure;
using CleanArchitecture.Application.Users.Queries.GetUser;
using Shouldly;
using Xunit;

namespace CleanArchitecture.Application.Tests.Users.Queries
{
    [Collection("QueryCollection")]
    public class GetUsersQueryHandlerTests
    {
        private readonly CleanArchitectureDbContext _context;

        public GetUsersQueryHandlerTests(QueryTestFixture fixture)
        {
            _context = fixture.Context;
        }

        [Fact]
        public async Task GetCustomerDetail()
        {
            var sut = new GetUserQueryHandler(_context);

            var result = await sut.Handle(new GetUserQuery { UserId = 1}, CancellationToken.None);

            result.ShouldBeOfType<UserDto>();
            result.Name.ShouldBe("Jason");
        }

    }
}
