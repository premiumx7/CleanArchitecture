﻿using System.Collections.Generic;
using CleanArchitecture.Domain.ValueObjects;

namespace CleanArchitecture.Domain.Entities
{
    public class User
    {
        public User()
        {
            Orders = new HashSet<Order>();
        }

        public int UserId { get; set; }
        public string Name { get; set; }
        public bool IsActive { get; set; }

        public AdAccount AdAccount { get; set; }

        public ICollection<Order> Orders { get; }
    }
}
